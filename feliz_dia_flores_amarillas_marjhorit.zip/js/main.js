const enter=document.getElementById("enter");
const universe=document.getElementById("universe");
const surprise=document.getElementById("surprise");
const final=document.getElementById("final");
const petals=document.querySelector(".petals");

enter.addEventListener("click",()=>{
  universe.classList.remove("hidden");
  universe.scrollIntoView({behavior:"smooth"});
  burst(18);
});
surprise.addEventListener("click",()=>{
  final.classList.remove("hidden");
  final.scrollIntoView({behavior:"smooth"});
  burst(45);
  surprise.textContent="🌻 Para ti, MARJHORIT ❤️";
});
function burst(n){
  for(let i=0;i<n;i++){
    const p=document.createElement("span");
    p.className="petal";
    p.textContent=Math.random()>.35?"🌻":"💛";
    p.style.left=Math.random()*100+"vw";
    p.style.animationDuration=(3+Math.random()*4)+"s";
    p.style.fontSize=(16+Math.random()*20)+"px";
    petals.appendChild(p);
    setTimeout(()=>p.remove(),7500);
  }
}
setInterval(()=>burst(2),1800);
